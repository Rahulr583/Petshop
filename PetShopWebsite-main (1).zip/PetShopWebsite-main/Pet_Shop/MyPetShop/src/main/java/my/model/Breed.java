package my.model;


    public enum Breed {
        GermanShepherd, BullDog, GoldenRetriever
    }

